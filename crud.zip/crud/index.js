import express, { request, response } from "express";
import mongoose from "mongoose";
import customer from "./customers.js";

const app = express();
app.use(express.json());

var Connection_string =
  "mongodb://127.0.0.1:27017/Thamizh?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+1.5.4";

//   insert
// -------------
app.use("/createcustomer", async (request, response) => {
  var customerData = await customer.create({
    cid: 8,
    cname: "hari",
    email: "hari@gmail.com",
    dob: "09-10-1993",
    age: "28",
    salary: 20000,
    did: 1,
    designation: "developer",
    pincode: 636100,
    pancard: "ahv123",
    mobilenumber: 9998887776,
    status: 0,
    authkey: "289sjdnsjdn729392",
  });
  response.status(200).json(customerData);
});

// insertmanycustomers
// -----------------------

app.use("/insertmanycustomers", async (request, response) => {
  var customerData = await customer.create([
    {
      cid: 9,
      cname: "harish",
      email: "harish@gmail.com",
      dob: "22-10-1993",
      age: "25",
      salary: 60000,
      did: 9,
      designation: " coder",
      pincode: 345432,
      pancard: "vha231",
      mobilenumber: 9997778880,
      status: 0,
      authkey: "289sj9ujdnsjdn729392",
    },
    {
      cid: 9,
      cname: "sankar",
      email: "sankar@gmail.com",
      dob: "15-10-1996",
      age: "26",
      salary: 68000,
      did: 10,
      designation: " team leader",
      pincode: 098765,
      pancard: "ahv3456",
      mobilenumber: 9087645345,
      status: 0,
      authkey: "289sj9ujdnsjdn72939392",
    },
  ]);
  response.status(200).json(customerData);
});

// selectall

app.use("/getdata", async (request, response) => {
  var customerData = await customer.find();
  response.status(200).json(customerData);
});

// selectone

app.use("/gettingsingleledata", async (request, response) => {
  //   console.log(request);
  let data = await customer.find({
    cname: request.body.name, // have to pass cname
  });
  response.status(200).json(data);
});

// updateOne

app.use("/updateone", async (request, response) => {
  let data = await customer.updateOne(
    { cid: request.params.cid },
    {
      $set: {
        cname: request.body.name,
      },
    }
  );
  response.sendStatus(200).json(data);
});

// updateMany or multi

app.use("/updateall", async (request, response) => {
  //console.log(request.body);
  let data = await customer.updateMany(
    {},
    {
      $set: {
        salary: request.body.salary,
      },
    }
  );

  response.status(200).json(data);
});

// deleteone

app.use("/deletecustomer", async (request, response) => {
  let deletecustomer = await customer.deleteOne({
    cname: request.body.name,
  });
  let existcustomer = await customer.find();
  console.log(existcustomer);

  response.status(200).json(deletecustomer);
});

// login check

app.use("/login", async (request, response) => {
  let data = await customer.findOne({
    $and: [
      { mobilenumber: request.body.mobilenumber },
      { cname: request.body.cname },
    ],
  });
  if (data) {
    response.status(200).json({ message: "Login success", status: 1 });
  } else {
    response.status(200).json({ message: "Login failes", status: 0 });
  }
});

app.use("/resetpswd", async (request, response) => {
  let data = await customer.updateOne(
    { email: request.params.email },
    { oldpassword: request.params.oldpassword},
    {
      $eq: [
        {
        //   oldpassword: request.body.oldpassword,
          password: request.body.password,
          confirmpassword: request.body.confirmpassword,
        },
      ],
      $set: [
        {
          newpassword: request.body.newpassword,
        },
      ],
    }
  );

  //   if(data.password === data.confirmpassword){
  //     newpassword:request.body.newpassword,

  //   }
  if (data) {
    response.status(200).json({ message: "password changed", status: -1 });
  } else {
    response.status(200).json({ message: "failed", status: 0 });
  }
});

// app.post("/reset",function(req,res){
//     customer.findByUsername(req.body.email).then(function(exixstdUser){
//     if (exixstdUser){
//         exixstdUser.setPassword(req.body.password, function(){
//             exixstdUser.save();
//             req.flash("success","password resetted");
//                 // res.redirect("/login");
//         });
//     } else {
//         req.flash("error","User doesnt exist");
//                 // res.redirect("/reset");
//     }
//     },function(err){
//         console.log(err);res.redirect("/");
//     });

//     });


// localhost port number setup

mongoose
  .connect(Connection_string)
  .then(() => {
    app.listen(3030, () => {
      console.log("running success");
    });
  })
  .catch((error) => {
    console.log(error);
  });