var empId = 1;
var empName = "mani";
// Tuple type variable 
var employee = [1, "mani"];
var employee = [1, " mani"];
var person = [1, "mani", true];
var user; // declare tuple variable
user = ["hari", true, 20, "Admin"]; // initialize tuple variable
console.log(user);
function getTime() {
    return new Date().getTime();
}
function multiply(a, b) {
    console.log(a * b);
}
multiply(1, 2);